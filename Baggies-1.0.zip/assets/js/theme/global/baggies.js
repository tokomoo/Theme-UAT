import $ from 'jquery';

export default function () {
    // Mobile menu script
    const trigger = $('.menu-toggle');
    const mobileMenu = $('.mobile-navigation');
    const menuChild = mobileMenu.find('.menu-item-has-children');

    trigger.on('click', e => {
        e.preventDefault();
        mobileMenu.slideToggle(200);
    });

    menuChild.each(function () {
        $(this).prepend('<button class="sub-trigger"><i class="fa fa-angle-down"></button>');
    });

    const subTrigger = $('.sub-trigger');

    subTrigger.on('click', e => {
        e.preventDefault();
        $(e.currentTarget).siblings('.sub-menu').slideToggle();
    });
}
